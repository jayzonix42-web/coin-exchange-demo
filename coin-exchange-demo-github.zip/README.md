# Coin Exchange Front-End Demo

A GitHub Pages-ready static front-end inspired by the screenshots you provided.

## Files
- `index.html` — page structure
- `style.css` — responsive styling
- `script.js` — presets, calculator, checkbox, and demo receipt modal

## GitHub Pages
1. Create a GitHub repository.
2. Upload these three files to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select your main branch and `/ (root)`.
6. Save and wait for GitHub Pages to publish.

This is intentionally a front-end demo: it does not connect to TikTok, process payments, transfer coins, or collect financial credentials.
